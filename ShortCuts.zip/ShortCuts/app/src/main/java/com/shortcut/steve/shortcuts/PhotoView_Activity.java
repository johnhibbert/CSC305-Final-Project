package com.shortcut.steve.shortcuts;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;

/**
 * Created by Steve on 4/17/2015.
 */
public class PhotoView_Activity extends Activity
{
    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.photoview_layout);

        // Create GridView
        GridView gridView = (GridView) findViewById(R.id.grid_view);

        // Instance of ImageAdapter Class
        gridView.setAdapter(new ImageAdapter(this));

        /**
         * OnClick event for a single picture
         * */
        gridView.setOnItemClickListener(new AdapterView.OnItemClickListener()
        {
            @Override
            public void onItemClick(AdapterView<?> parent, View v, int position, long id)
            {
                // Sending image id to FullScreenActivity
                Intent i = new Intent(getApplicationContext(), FullImage_Activity.class);

                // Pass array index
                i.putExtra("id", position);

                // Start
                startActivity(i);
            }
        });
    }
}
